#!/system/bin/sh
RUNTIME=/data/adb/batteryforge

# Restore baseline values
rest_g() { [ -f "$RUNTIME/saved/$1" ] && settings put global "$1" "$(cat "$RUNTIME/saved/$1")" 2>/dev/null; }
rest_s() { [ -f "$RUNTIME/saved/$1" ] && settings put secure "$1" "$(cat "$RUNTIME/saved/$1")" 2>/dev/null; }

rest_g sync_automatically
rest_g background_data
rest_g low_power
rest_g ble_scan_always_enabled
rest_g wifi_scan_throttle_enabled
rest_g cached_apps_freezer
rest_g app_standby_enabled
rest_g app_background_limit
rest_s backup_auto_restore
rest_s location_mode

cmd netpolicy set restrict-background false 2>/dev/null

# Release gated apps
if [ -f "$RUNTIME/apps.list" ]; then
    for PKG in $(grep -v '^#' "$RUNTIME/apps.list" | grep -v '^[[:space:]]*$' | sed 's/[[:space:]]*$//'); do
        cmd appops set "$PKG" RUN_IN_BACKGROUND allow 2>/dev/null
        cmd appops set "$PKG" RUN_ANY_IN_BACKGROUND allow 2>/dev/null
        cmd appops set "$PKG" WAKE_LOCK allow 2>/dev/null
        cmd deviceidle set-standby-bucket "$PKG" active 2>/dev/null || am set-standby-bucket "$PKG" active 2>/dev/null
        U=$(dumpsys package "$PKG" 2>/dev/null | grep -m1 'userId=' | sed 's/.*userId=//;s/[^0-9].*//')
        [ -n "$U" ] && cmd netpolicy remove restrict-background-blacklist "$U" 2>/dev/null
    done
fi

cmd appops set com.android.vending RUN_IN_BACKGROUND allow 2>/dev/null
cmd appops set com.android.vending RUN_ANY_IN_BACKGROUND allow 2>/dev/null

# Restore CPU if thermal control was active
if [ -f "$RUNTIME/saved/cpu0_governor" ]; then
    for cpu in /sys/devices/system/cpu/cpu[0-7]; do
        [ -d "$cpu/cpufreq" ] || continue
        cat "$RUNTIME/saved/cpu0_governor" 2>/dev/null > "$cpu/cpufreq/scaling_governor" 2>/dev/null
    done
fi
if [ -f "$RUNTIME/saved/cpu0_max_freq" ]; then
    for cpu in /sys/devices/system/cpu/cpu[0-3]; do
        [ -d "$cpu/cpufreq" ] || continue
        cat "$RUNTIME/saved/cpu0_max_freq" 2>/dev/null > "$cpu/cpufreq/scaling_max_freq" 2>/dev/null
    done
fi
if [ -f "$RUNTIME/saved/cpu4_max_freq" ]; then
    for cpu in /sys/devices/system/cpu/cpu[4-7]; do
        [ -d "$cpu/cpufreq" ] || continue
        cat "$RUNTIME/saved/cpu4_max_freq" 2>/dev/null > "$cpu/cpufreq/scaling_max_freq" 2>/dev/null
    done
fi

# Kill daemon
[ -f "$RUNTIME/daemon.pid" ] && kill "$(cat "$RUNTIME/daemon.pid")" 2>/dev/null
[ -f "$RUNTIME/webui.pid" ]  && kill "$(cat "$RUNTIME/webui.pid")"  2>/dev/null

rm -rf "$RUNTIME"
