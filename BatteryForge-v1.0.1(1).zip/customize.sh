#!/sbin/sh
SKIPUNZIP=0
ui_print "********************************"
ui_print "   BatteryForge v1.0.1"
ui_print "   AOSP Battery + Thermal Optimizer"
ui_print "********************************"
ui_print ""
RUNTIME=/data/adb/batteryforge
mkdir -p "$RUNTIME/www/cgi-bin"
cp -rf "$MODPATH/www/." "$RUNTIME/www/"
cp -f "$MODPATH/batteryforge-daemon.sh" "$RUNTIME/batteryforge-daemon.sh"

if [ ! -f "$RUNTIME/config.conf" ]; then
cat > "$RUNTIME/config.conf" << 'EOF'
# BatteryForge v1.0 config - edits apply live (no reboot)
ENABLED=true
DISABLE_AUTO_SYNC=true
DISABLE_BACKGROUND_DATA=true
ENABLE_DATA_SAVER=false
ENABLE_BATTERY_SAVER=false
DISABLE_GOOGLE_BACKUP=true
PAUSE_PLAY_UPDATES=true
LIMIT_CACHED_PROCS=true
MAX_CACHED_PROCS=4
DISABLE_SCANS=true
RESTRICT_LOCATION=true
STANDBY_BUCKET=true
GATE_APPS=true
RESTRICT_APP_NETWORK=true
FORCE_STOP_GATED_APPS=false
BATTERY_THRESHOLD=0
SCHEDULE_ENABLED=false
SCHEDULE_SH=23
SCHEDULE_SM=0
SCHEDULE_EH=6
SCHEDULE_EM=0
POLL_INTERVAL=5
DEBOUNCE_COUNT=2
WEBUI_PORT=8743
LOG_LEVEL=normal
THERMAL_CONTROL=false
CPU_GOVERNOR_ON_BATTERY=schedutil
CPU_MAX_FREQ_LITTLE=1804800
CPU_MAX_FREQ_BIG=2208000
CPU_GOVERNOR_ON_CHARGE=schedutil
CPU_MAX_FREQ_LITTLE_CHARGE=2803200
CPU_MAX_FREQ_BIG_CHARGE=2918400
EOF
    ui_print "- created default config.conf"
fi

if [ ! -f "$RUNTIME/apps.list" ]; then
cat > "$RUNTIME/apps.list" << 'EOF'
# BatteryForge gated apps (one package per line)
com.google.android.youtube
com.zhiliaoapp.musically.go
com.brave.browser
com.android.chrome
com.google.android.apps.photos
com.instagram.android
com.supercell.clashroyale
com.google.android.googlequicksearchbox
EOF
    ui_print "- created default apps.list"
fi

# CRITICAL: chmod 755 for API and daemon, 644 for configs
chmod 755 "$RUNTIME" "$RUNTIME/batteryforge-daemon.sh" "$RUNTIME/www/cgi-bin" "$RUNTIME/www/cgi-bin/api"
chmod 644 "$RUNTIME/config.conf" "$RUNTIME/apps.list" 2>/dev/null
chmod -R 644 "$RUNTIME/www" 2>/dev/null
# Re-fix API after the recursive chmod above
chmod 755 "$RUNTIME/www/cgi-bin" "$RUNTIME/www/cgi-bin/api" 2>/dev/null

touch "$MODPATH/skip_mount"

ui_print ""
ui_print "- WebUI:  http://127.0.0.1:8743"
ui_print "- CLI:    batteryforge status|battery|charging|add PKG|..."
ui_print "- Tap module action button or reboot to start"
ui_print ""
