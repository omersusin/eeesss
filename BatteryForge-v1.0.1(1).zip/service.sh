#!/system/bin/sh
# BatteryForge service.sh - detach daemon
while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 2; done
sleep 8
[ -x /data/adb/batteryforge/batteryforge-daemon.sh ] || exit 0
[ -f /data/adb/batteryforge/daemon.pid ] && kill -0 "$(cat /data/adb/batteryforge/daemon.pid)" 2>/dev/null && exit 0
nohup setsid /data/adb/batteryforge/batteryforge-daemon.sh >/dev/null 2>&1 < /dev/null &
disown 2>/dev/null
exit 0
