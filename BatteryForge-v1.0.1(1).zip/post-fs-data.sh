#!/system/bin/sh
# Warm start - try to bring daemon up without reboot
sleep 6
[ -x /data/adb/batteryforge/batteryforge-daemon.sh ] || exit 0
[ -f /data/adb/batteryforge/daemon.pid ] && kill -0 "$(cat /data/adb/batteryforge/daemon.pid)" 2>/dev/null && exit 0
nohup setsid /data/adb/batteryforge/batteryforge-daemon.sh >/dev/null 2>&1 < /dev/null &
disown 2>/dev/null
exit 0
