#!/system/bin/sh
RUNTIME=/data/adb/batteryforge
DAEMON="$RUNTIME/batteryforge-daemon.sh"
PORT=$(grep '^WEBUI_PORT=' "$RUNTIME/config.conf" 2>/dev/null | cut -d= -f2 | tr -d '[:space:]')
[ -z "$PORT" ] && PORT=8743
echo "================================"
echo "  BatteryForge"
echo "================================"
if [ ! -f "$RUNTIME/daemon.pid" ] || ! kill -0 "$(cat "$RUNTIME/daemon.pid" 2>/dev/null)" 2>/dev/null; then
    if [ -x "$DAEMON" ]; then
        echo "[..] daemon not running - starting now"
        nohup setsid "$DAEMON" >/dev/null 2>&1 < /dev/null &
        disown 2>/dev/null
        sleep 3
    else
        echo "[!!] daemon binary missing - re-flash the module"
    fi
fi
if [ -f "$RUNTIME/daemon.pid" ] && kill -0 "$(cat "$RUNTIME/daemon.pid")" 2>/dev/null; then
    echo "[OK] daemon running (pid $(cat "$RUNTIME/daemon.pid"))"
else
    echo "[!!] daemon failed to start - see batteryforge.log"
fi
STATE=$(cat "$RUNTIME/state" 2>/dev/null)
case "$STATE" in
    charging) echo ">>> CHARGING (gates released)" ;;
    battery)  echo ">>> BATTERY (gates engaged)" ;;
    *)        echo "??? unknown" ;;
esac
echo ""
echo "WebUI: http://127.0.0.1:$PORT"
echo "Opening browser..."
am start -a android.intent.action.VIEW -d "http://127.0.0.1:$PORT" 2>/dev/null
