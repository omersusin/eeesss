#!/system/bin/sh
# BatteryForge Daemon v1.0
# Charging-aware battery optimizer with thermal control for Poco F5 / AOSP

trap '' HUP
RUNTIME="/data/adb/batteryforge"
WWW="$RUNTIME/www"
CONF="$RUNTIME/config.conf"
APPS="$RUNTIME/apps.list"
LOGF="$RUNTIME/batteryforge.log"
STATEFILE="$RUNTIME/state"
PIDFILE="$RUNTIME/daemon.pid"
WEBPID="$RUNTIME/webui.pid"

if [ -f "$PIDFILE" ]; then
    OP=$(cat "$PIDFILE" 2>/dev/null)
    [ -n "$OP" ] && kill -0 "$OP" 2>/dev/null && exit 0
fi

echo $$ > "$PIDFILE"
date +%s > "$RUNTIME/start_epoch"

trap 'rm -f "$PIDFILE"; [ -f "$WEBPID" ] && kill "$(cat "$WEBPID")" 2>/dev/null; exit 0' TERM INT

log() {
    _l="$1"; shift
    echo "[$(date '+%m-%d %H:%M:%S')] [$_l] $*" >> "$LOGF" 2>/dev/null
    _n=$(wc -l < "$LOGF" 2>/dev/null)
    _n=${_n:-0}
    [ "$_n" -gt 1000 ] && { tail -500 "$LOGF" > "$LOGF.tmp" && mv "$LOGF.tmp" "$LOGF"; }
}

get_conf() {
    _v=$(grep "^$1=" "$CONF" 2>/dev/null | head -1 | cut -d'=' -f2 | tr -d '[:space:]')
    [ -n "$_v" ] && printf '%s' "$_v" || printf '%s' "$2"
}

get_apps() {
    grep -v '^#' "$APPS" 2>/dev/null | grep -v '^[[:space:]]*$' | sed 's/[[:space:]]*$//'
}

# Save baseline once for clean uninstall
save_baseline_once() {
    [ -d "$RUNTIME/saved" ] && return 0
    mkdir -p "$RUNTIME/saved"
    settings get global sync_automatically         > "$RUNTIME/saved/sync_automatically" 2>/dev/null
    settings get global background_data            > "$RUNTIME/saved/background_data" 2>/dev/null
    settings get global low_power                  > "$RUNTIME/saved/low_power" 2>/dev/null
    settings get global ble_scan_always_enabled    > "$RUNTIME/saved/ble_scan_always_enabled" 2>/dev/null
    settings get global wifi_scan_throttle_enabled > "$RUNTIME/saved/wifi_scan_throttle_enabled" 2>/dev/null
    settings get secure backup_auto_restore        > "$RUNTIME/saved/backup_auto_restore" 2>/dev/null
    settings get secure location_mode              > "$RUNTIME/saved/location_mode" 2>/dev/null
    settings get global cached_apps_freezer          > "$RUNTIME/saved/cached_apps_freezer" 2>/dev/null
    settings get global app_standby_enabled          > "$RUNTIME/saved/app_standby_enabled" 2>/dev/null
    settings get global app_background_limit         > "$RUNTIME/saved/app_background_limit" 2>/dev/null
    # Save CPU state
    cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null > "$RUNTIME/saved/cpu0_governor"
    cat /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor 2>/dev/null > "$RUNTIME/saved/cpu4_governor"
    cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq 2>/dev/null > "$RUNTIME/saved/cpu0_max_freq"
    cat /sys/devices/system/cpu/cpu4/cpufreq/scaling_max_freq 2>/dev/null > "$RUNTIME/saved/cpu4_max_freq"
    log INFO "saved baseline settings snapshot"
}

is_foreground() {
    _fg=$(dumpsys activity activities 2>/dev/null | grep -m1 -E 'topResumedActivity=|mResumedActivity=|ResumedActivity')
    case "$_fg" in *"$1"/*) return 0 ;; esac
    return 1
}

get_charging_state() {
    for f in /sys/class/power_supply/*/status; do
        [ -f "$f" ] || continue
        case "$(cat "$f" 2>/dev/null)" in Charging|Full) echo charging; return ;; esac
    done
    for f in /sys/class/power_supply/*/online; do
        [ -f "$f" ] || continue
        [ "$(cat "$f" 2>/dev/null)" = "1" ] && { echo charging; return; }
    done
    dumpsys battery 2>/dev/null | grep -qE 'powered: true' && { echo charging; return; }
    echo battery
}

get_uid() {
    dumpsys package "$1" 2>/dev/null | grep -m1 'userId=' | sed 's/.*userId=//;s/[^0-9].*//'
}

in_schedule_window() {
    [ "$(get_conf SCHEDULE_ENABLED false)" = true ] || return 1
    sh=$(($(get_conf SCHEDULE_SH 23)+0)); sm=$(($(get_conf SCHEDULE_SM 0)+0))
    eh=$(($(get_conf SCHEDULE_EH 6)+0));  em=$(($(get_conf SCHEDULE_EM 0)+0))
    start=$((sh*100+sm)); end=$((eh*100+em)); now=$(($(date +%H%M)+0))
    if [ "$start" -le "$end" ]; then
        [ "$now" -ge "$start" ] && [ "$now" -lt "$end" ] && return 0
    else
        [ "$now" -ge "$start" ] || [ "$now" -lt "$end" ] && return 0
    fi
    return 1
}

RELAXED=false
effective_state() {
    RELAXED=false
    if in_schedule_window; then echo battery; return; fi
    cs=$(get_charging_state)
    if [ "$cs" = charging ]; then echo charging; return; fi
    thr=$(get_conf BATTERY_THRESHOLD 0)
    case "$thr" in ''|0) echo battery; return ;; esac
    cap=$(cat /sys/class/power_supply/battery/capacity 2>/dev/null)
    case "$cap" in ''|*[!0-9]*) echo battery; return ;; esac
    if [ "$cap" -ge "$thr" ]; then RELAXED=true; echo charging; else echo battery; fi
}

# ===== THERMAL / CPU CONTROL =====
apply_cpu_battery() {
    [ "$(get_conf THERMAL_CONTROL false)" = true ] || return 0
    gov=$(get_conf CPU_GOVERNOR_ON_BATTERY schedutil)
    little=$(get_conf CPU_MAX_FREQ_LITTLE 1804800)
    big=$(get_conf CPU_MAX_FREQ_BIG 2208000)

    # Try with root shell
    for cpu in /sys/devices/system/cpu/cpu[0-7]; do
        [ -d "$cpu/cpufreq" ] || continue
        echo "$gov" > "$cpu/cpufreq/scaling_governor" 2>/dev/null
    done
    # Poco F5 has cpu0-3 (little) and cpu4-7 (big)
    for cpu in /sys/devices/system/cpu/cpu[0-3]; do
        [ -d "$cpu/cpufreq" ] || continue
        echo "$little" > "$cpu/cpufreq/scaling_max_freq" 2>/dev/null
    done
    for cpu in /sys/devices/system/cpu/cpu[4-7]; do
        [ -d "$cpu/cpufreq" ] || continue
        echo "$big" > "$cpu/cpufreq/scaling_max_freq" 2>/dev/null
    done
    log INFO "CPU: governor=$gov little=$little big=$big"
}

apply_cpu_charging() {
    [ "$(get_conf THERMAL_CONTROL false)" = true ] || return 0
    gov=$(get_conf CPU_GOVERNOR_ON_CHARGE schedutil)
    little=$(get_conf CPU_MAX_FREQ_LITTLE_CHARGE 2803200)
    big=$(get_conf CPU_MAX_FREQ_BIG_CHARGE 2918400)

    for cpu in /sys/devices/system/cpu/cpu[0-7]; do
        [ -d "$cpu/cpufreq" ] || continue
        echo "$gov" > "$cpu/cpufreq/scaling_governor" 2>/dev/null
    done
    for cpu in /sys/devices/system/cpu/cpu[0-3]; do
        [ -d "$cpu/cpufreq" ] || continue
        echo "$little" > "$cpu/cpufreq/scaling_max_freq" 2>/dev/null
    done
    for cpu in /sys/devices/system/cpu/cpu[4-7]; do
        [ -d "$cpu/cpufreq" ] || continue
        echo "$big" > "$cpu/cpufreq/scaling_max_freq" 2>/dev/null
    done
    log INFO "CPU: governor=$gov little=$little big=$big (charging)"
}

# ===== BATTERY GATES =====
apply_battery() {
    log INFO "=== BATTERY: engaging gates ==="
    save_baseline_once

    # Sync & Data
    [ "$(get_conf DISABLE_AUTO_SYNC true)" = true ]       && settings put global sync_automatically 0 2>/dev/null
    [ "$(get_conf DISABLE_BACKGROUND_DATA true)" = true ] && settings put global background_data 0 2>/dev/null
    [ "$(get_conf ENABLE_DATA_SAVER false)" = true ]      && cmd netpolicy set restrict-background true 2>/dev/null
    [ "$(get_conf ENABLE_BATTERY_SAVER false)" = true ]   && settings put global low_power 1 2>/dev/null

    # Google Backup
    if [ "$(get_conf DISABLE_GOOGLE_BACKUP true)" = true ]; then
        settings put secure backup_auto_restore 0 2>/dev/null
        settings put global deferring_full_backup 1 2>/dev/null
        settings put global deferring_kv_backup 1 2>/dev/null
    fi

    # Scans
    if [ "$(get_conf DISABLE_SCANS true)" = true ]; then
        settings put global ble_scan_always_enabled 0 2>/dev/null
        settings put global wifi_scan_throttle_enabled 1 2>/dev/null
    fi

    # Location
    if [ "$(get_conf RESTRICT_LOCATION true)" = true ]; then
        cur=$(settings get secure location_mode 2>/dev/null)
        echo "$cur" > "$RUNTIME/saved_location"
        settings put secure location_mode 2 2>/dev/null
    fi

    # Cached procs
    [ "$(get_conf LIMIT_CACHED_PROCS true)" = true ] && settings put global app_background_limit "$(get_conf MAX_CACHED_PROCS 4)" 2>/dev/null

    # Cached apps freezer
    settings put global cached_apps_freezer enabled 2>/dev/null
    settings put global app_standby_enabled 1 2>/dev/null

    # Play Store
    if [ "$(get_conf PAUSE_PLAY_UPDATES true)" = true ]; then
        cmd appops set com.android.vending RUN_IN_BACKGROUND deny 2>/dev/null
        cmd appops set com.android.vending RUN_ANY_IN_BACKGROUND deny 2>/dev/null
    fi

    # Per-app gating
    if [ "$(get_conf GATE_APPS true)" = true ]; then
        for p in $(get_apps); do
            cmd appops set "$p" RUN_IN_BACKGROUND deny 2>/dev/null
            cmd appops set "$p" RUN_ANY_IN_BACKGROUND deny 2>/dev/null
            cmd appops set "$p" WAKE_LOCK ignore 2>/dev/null

            if [ "$(get_conf STANDBY_BUCKET true)" = true ]; then
                cmd deviceidle set-standby-bucket "$p" restricted >/dev/null 2>&1 || am set-standby-bucket "$p" restricted >/dev/null 2>&1 || log WARN "set-standby-bucket restricted failed: $p"
            fi

            if [ "$(get_conf RESTRICT_APP_NETWORK true)" = true ]; then
                u=$(get_uid "$p")
                [ -n "$u" ] && cmd netpolicy add restrict-background-blacklist "$u" 2>/dev/null
            fi

            if [ "$(get_conf FORCE_STOP_GATED_APPS false)" = true ]; then
                if is_foreground "$p"; then
                    log INFO "skip force-stop $p (foreground)"
                else
                    am force-stop "$p" 2>/dev/null
                fi
            fi
            log INFO "gated $p"
        done
    fi

    # CPU Thermal
    apply_cpu_battery

    echo battery > "$STATEFILE"
    date +%s > "$RUNTIME/last_change"
    log INFO "=== BATTERY: engaged ==="
}

apply_charging() {
    log INFO "=== CHARGING: releasing gates ==="

    [ "$(get_conf DISABLE_AUTO_SYNC true)" = true ]       && settings put global sync_automatically 1 2>/dev/null
    [ "$(get_conf DISABLE_BACKGROUND_DATA true)" = true ] && settings put global background_data 1 2>/dev/null
    [ "$(get_conf ENABLE_DATA_SAVER false)" = true ]      && cmd netpolicy set restrict-background false 2>/dev/null
    [ "$(get_conf ENABLE_BATTERY_SAVER false)" = true ]   && settings put global low_power 0 2>/dev/null

    if [ "$(get_conf DISABLE_GOOGLE_BACKUP true)" = true ]; then
        settings put secure backup_auto_restore 1 2>/dev/null
        settings put global deferring_full_backup 0 2>/dev/null
        settings put global deferring_kv_backup 0 2>/dev/null
    fi

    if [ "$(get_conf DISABLE_SCANS true)" = true ]; then
        settings put global ble_scan_always_enabled 1 2>/dev/null
        settings put global wifi_scan_throttle_enabled 0 2>/dev/null
    fi

    if [ "$(get_conf RESTRICT_LOCATION true)" = true ]; then
        prev=$(cat "$RUNTIME/saved_location" 2>/dev/null)
        case "$prev" in ''|null) prev=3 ;; esac
        settings put secure location_mode "$prev" 2>/dev/null
    fi

    [ "$(get_conf LIMIT_CACHED_PROCS true)" = true ] && settings put global app_background_limit 16 2>/dev/null

    cmd appops set com.android.vending RUN_IN_BACKGROUND allow 2>/dev/null
    cmd appops set com.android.vending RUN_ANY_IN_BACKGROUND allow 2>/dev/null

    if [ "$(get_conf GATE_APPS true)" = true ]; then
        for p in $(get_apps); do
            cmd appops set "$p" RUN_IN_BACKGROUND allow 2>/dev/null
            cmd appops set "$p" RUN_ANY_IN_BACKGROUND allow 2>/dev/null
            cmd appops set "$p" WAKE_LOCK allow 2>/dev/null

            if [ "$(get_conf STANDBY_BUCKET true)" = true ]; then
                cmd deviceidle set-standby-bucket "$p" active >/dev/null 2>&1 || am set-standby-bucket "$p" active >/dev/null 2>&1 || log WARN "set-standby-bucket active failed: $p"
            fi

            if [ "$(get_conf RESTRICT_APP_NETWORK true)" = true ]; then
                u=$(get_uid "$p")
                [ -n "$u" ] && cmd netpolicy remove restrict-background-blacklist "$u" 2>/dev/null
            fi
            log INFO "released $p"
        done
    fi

    # CPU Thermal restore
    apply_cpu_charging

    echo charging > "$STATEFILE"
    date +%s > "$RUNTIME/last_change"
    log INFO "=== CHARGING: released ==="
}

# WebUI via busybox httpd
find_busybox() {
    for c in /data/adb/magisk/busybox /data/adb/ksu/bin/busybox /data/adb/ap/bin/busybox /sbin/busybox /system/xbin/busybox /system/bin/busybox; do
        [ -x "$c" ] || continue
        "$c" --list 2>/dev/null | grep -qx httpd && { echo "$c"; return 0; }
    done
    command -v busybox >/dev/null 2>&1 && busybox --list 2>/dev/null | grep -qx httpd && { echo busybox; return 0; }
    return 1
}

start_webui() {
    PORT=$(get_conf WEBUI_PORT 8743)
    BB=$(find_busybox)
    if [ -z "$BB" ]; then
        log ERROR "busybox httpd not found - WebUI disabled (gating still works)"
        return 1
    fi
    [ -f "$WEBPID" ] && kill "$(cat "$WEBPID")" 2>/dev/null
    "$BB" httpd -p 127.0.0.1:"$PORT" -h "$WWW" >/dev/null 2>&1 &
    echo $! > "$WEBPID"
    echo "$PORT" > "$RUNTIME/current_port"
    sleep 1
    if kill -0 "$(cat "$WEBPID" 2>/dev/null)" 2>/dev/null; then
        log INFO "WebUI up: http://127.0.0.1:$PORT"
    else
        log ERROR "httpd failed to start"
    fi
}

log INFO "BatteryForge daemon v1.0.1 starting (pid $$)"
mkdir -p "$WWW/cgi-bin"
start_webui

CUR=$(effective_state)
if in_schedule_window; then echo true > "$RUNTIME/schedule_active"; else echo false > "$RUNTIME/schedule_active"; fi
if [ "$RELAXED" = true ]; then echo true > "$RUNTIME/relaxed"; else echo false > "$RUNTIME/relaxed"; fi
if [ "$CUR" = battery ]; then apply_battery; else apply_charging; fi

DEB=0; TICK=0
while true; do
    if [ "$(get_conf ENABLED true)" != true ]; then sleep 15; continue; fi
    POLL=$(get_conf POLL_INTERVAL 5)
    DBM=$(get_conf DEBOUNCE_COUNT 2)

    # Handle CLI commands
    if [ -f "$RUNTIME/cmd" ]; then
        C=$(cat "$RUNTIME/cmd" 2>/dev/null)
        rm -f "$RUNTIME/cmd"
        case "$C" in
            battery) apply_battery; CUR=battery ;;
            charging) apply_charging; CUR=charging ;;
        esac
    fi

    cap=$(cat /sys/class/power_supply/battery/capacity 2>/dev/null)
    [ -n "$cap" ] && echo "$cap" > "$RUNTIME/battery_level"

    DET=$(effective_state)
    if in_schedule_window; then echo true > "$RUNTIME/schedule_active"; else echo false > "$RUNTIME/schedule_active"; fi
    if [ "$RELAXED" = true ]; then echo true > "$RUNTIME/relaxed"; else echo false > "$RUNTIME/relaxed"; fi

    if [ "$DET" != "$CUR" ]; then
        DEB=$((DEB + 1))
        if [ "$DEB" -ge "$DBM" ]; then
            CUR=$DET
            DEB=0
            if [ "$CUR" = battery ]; then apply_battery; else apply_charging; fi
        fi
    else
        DEB=0
    fi

    TICK=$((TICK + 1))
    if [ $((TICK % 12)) -eq 0 ]; then
        WP=$(cat "$WEBPID" 2>/dev/null)
        CP=$(cat "$RUNTIME/current_port" 2>/dev/null)
        NP=$(get_conf WEBUI_PORT 8743)
        if [ -z "$WP" ] || ! kill -0 "$WP" 2>/dev/null; then
            log WARN "WebUI down - restarting"
            start_webui
        elif [ "$CP" != "$NP" ]; then
            log INFO "WebUI port changed $CP -> $NP - restarting"
            kill "$WP" 2>/dev/null
            start_webui
        fi
    fi
    sleep "$POLL"
done
